part of 'users_bloc.dart';

abstract class UsersState extends Equatable {
  const UsersState();

  // @override
  // List<Object> get props => [];
}

class UsersInitial extends UsersState {
  @override
  List<Object> get props => [];
}

class UsersError extends UsersState {
  @override
  List<Object> get props => [];
}

class UsersEmpty extends UsersState {
  @override
  List<Object> get props => [];
}

class UsersLoading extends UsersState {
  @override
  List<Object> get props => [];
}

class UsersLoaded extends UsersState {
  // this will create black object
  final ResponseUsers responseUsers;

  //This will initialise object direactly
  const UsersLoaded({@required this.responseUsers})
      : assert(responseUsers != null);

  @override
  List<Object> get props => [];
}

class PriceListLoaded extends UsersState {
  // this will create black object
  final PriceList priceList;

  //This will initialise object direactly
  const PriceListLoaded({@required this.priceList}) : assert(priceList != null);

  @override
  List<Object> get props => [];
}
