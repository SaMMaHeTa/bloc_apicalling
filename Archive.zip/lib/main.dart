import 'dart:io';

import 'package:bloc_apicalling/HomePage.dart';
import 'package:bloc_apicalling/bloc/index.dart';
import 'package:bloc_apicalling/repositories/ApiRepoRepository.dart';
import 'package:bloc_apicalling/repositories/ApiRepoRepositoryProvider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:dynamic_theme/dynamic_theme.dart';
import 'package:splashscreen/splashscreen.dart';

class UsersBlocObserver extends BlocObserver {
  @override
  void onEvent(Bloc bloc, Object event) {
    print(event);
    super.onEvent(bloc, event);
  }

  @override
  void onChange(Cubit cubit, Change change) {
    print(change);
    super.onChange(cubit, change);
  }

  @override
  void onTransition(Bloc bloc, Transition transition) {
    print(transition);
    super.onTransition(bloc, transition);
  }

  @override
  void onError(Cubit cubit, Object error, StackTrace stackTrace) {
    print(error);
    super.onError(cubit, error, stackTrace);
  }
}

void main() {
  Bloc.observer = UsersBlocObserver();
  final ApiRepoRepository apiRepoRepository = ApiRepoRepository(
      apiHttpClientRepoProvider:
          ApiRepoRepositoryProvider(httpClient: HttpClient()));
  print("REPO CREATED");
  runApp(App(repository: apiRepoRepository));
}

class App extends StatelessWidget {
  final ApiRepoRepository repository;

  App({Key key, @required this.repository})
      : assert(repository != null),
        super(key: key);
  @override
  Widget build(BuildContext context) {
    return new DynamicTheme(
        defaultBrightness: Brightness.light,
        data: (brightness) => new ThemeData(
              primarySwatch: Colors.deepPurple,
              brightness: brightness,
            ),
        themedWidgetBuilder: (context, theme) {
          return new MaterialApp(
              title: 'Flutter Demo',
              theme: theme,
              debugShowCheckedModeBanner: false,
              home: _MyAppState(repository: repository));
        });
  }
}

class _MyAppState extends StatelessWidget {
  final ApiRepoRepository repository;

  _MyAppState({Key key, @required this.repository})
      : assert(repository != null),
        super(key: key);
  @override
  Widget build(BuildContext context) {
    return new SplashScreen(
        seconds: 4,
        navigateAfterSeconds: new AfterSplash(repository: repository),
        title: new Text(
          "SaM's DeV",
          style: new TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 20.0,
              color: Theme.of(context).textSelectionColor),
        ),
        imageBackground: new NetworkImage('https://i.imgur.com/TyCSG9A.png'),
        backgroundColor: Theme.of(context).backgroundColor,
        styleTextUnderTheLoader: new TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 20.0,
            color: Theme.of(context).secondaryHeaderColor),
        loadingText: new Text("SaM's DeV"),
        onClick: () => print("Flutter Egypt"),
        loaderColor: Colors.red);
  }
}

class AfterSplash extends StatelessWidget {
  final ApiRepoRepository repository;

  AfterSplash({Key key, @required this.repository})
      : assert(repository != null),
        super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('USERS'),
      ),
      body: SafeArea(
          child: BlocProvider(
        create: (context) => UsersBloc(apiRepoRepository: repository),
        child: HomePage(),
      )),
    );
  }
}
