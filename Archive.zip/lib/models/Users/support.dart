import 'package:equatable/equatable.dart';

class Support extends Equatable {
	final String url;
	final String text;

	const Support({this.url, this.text});

	@override
	String toString() => 'Support(url: $url, text: $text)';

	factory Support.fromJson(Map<String, dynamic> json) {
		return Support(
			url: json['url'] as String,
			text: json['text'] as String,
		);
	}

	Map<String, dynamic> toJson() {
		return {
			'url': url,
			'text': text,
		};
	}

	Support copyWith({
		String url,
		String text,
	}) {
		return Support(
			url: url ?? this.url,
			text: text ?? this.text,
		);
	}

	@override
	List<Object> get props => [url, text];
}
