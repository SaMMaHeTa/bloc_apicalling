import 'package:bloc_apicalling/models/PriceList/price_list.dart';
import 'package:bloc_apicalling/models/Users/response_users.dart';
import 'package:bloc_apicalling/models/index.dart';
import 'package:bloc_apicalling/repositories/ApiRepoRepositoryProvider.dart';
import 'package:meta/meta.dart';

class ApiRepoRepository {
  final ApiRepoRepositoryProvider apiHttpClientRepoProvider;

  const ApiRepoRepository({@required this.apiHttpClientRepoProvider})
      : assert(apiHttpClientRepoProvider != null);

  Future<ResponseUsers> getUsersData() async {
    return await apiHttpClientRepoProvider.getUsersData();
  }

  Future<PriceList> getPriceList() async {
    return await apiHttpClientRepoProvider.getPriceList();
  }
}
