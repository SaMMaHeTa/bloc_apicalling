import 'package:equatable/equatable.dart';

class Bits extends Equatable {
  final String name;
  final String unit;
  final double value;
  final String type;

  const Bits({
    this.name,
    this.unit,
    this.value,
    this.type,
  });

  @override
  String toString() {
    return 'Bits(name: $name, unit: $unit, value: $value, type: $type)';
  }

  factory Bits.fromJson(Map<String, dynamic> json) {
    return Bits(
      name: json['name'] as String,
      unit: json['unit'] as String,
      value: json['value'] as double,
      type: json['type'] as String,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'unit': unit,
      'value': value,
      'type': type,
    };
  }

  Bits copyWith({
    String name,
    String unit,
    int value,
    String type,
  }) {
    return Bits(
      name: name ?? this.name,
      unit: unit ?? this.unit,
      value: value ?? this.value,
      type: type ?? this.type,
    );
  }

  @override
  List<Object> get props => [name, unit, value, type];
}
