import 'package:equatable/equatable.dart';

import "rates.dart";

class ExchangeRates extends Equatable {
	final Rates rates;

	const ExchangeRates({this.rates});

	@override
	String toString() => 'ExchangeRates(rates: $rates)';

	factory ExchangeRates.fromJson(Map<String, dynamic> json) {
		return ExchangeRates(
			rates: json['rates'] == null
					? null
					: Rates.fromJson(json['rates'] as Map<String, dynamic>),
		);
	}

	Map<String, dynamic> toJson() {
		return {
			'rates': rates?.toJson(),
		};
	}

	ExchangeRates copyWith({
		Rates rates,
	}) {
		return ExchangeRates(
			rates: rates ?? this.rates,
		);
	}

	@override
	List<Object> get props => [rates];
}
