import 'package:equatable/equatable.dart';

class Jpy extends Equatable {
	final String name;
	final String unit;
	final double value;
	final String type;

	const Jpy({
		this.name,
		this.unit,
		this.value,
		this.type,
	});

	@override
	String toString() {
		return 'Jpy(name: $name, unit: $unit, value: $value, type: $type)';
	}

	factory Jpy.fromJson(Map<String, dynamic> json) {
		return Jpy(
			name: json['name'] as String,
			unit: json['unit'] as String,
			value: json['value'] as double,
			type: json['type'] as String,
		);
	}

	Map<String, dynamic> toJson() {
		return {
			'name': name,
			'unit': unit,
			'value': value,
			'type': type,
		};
	}

	Jpy copyWith({
		String name,
		String unit,
		double value,
		String type,
	}) {
		return Jpy(
			name: name ?? this.name,
			unit: unit ?? this.unit,
			value: value ?? this.value,
			type: type ?? this.type,
		);
	}

	@override
	List<Object> get props => [name, unit, value, type];
}
