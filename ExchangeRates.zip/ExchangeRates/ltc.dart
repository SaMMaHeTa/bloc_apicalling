import 'package:equatable/equatable.dart';

class Ltc extends Equatable {
	final String name;
	final String unit;
	final double value;
	final String type;

	const Ltc({
		this.name,
		this.unit,
		this.value,
		this.type,
	});

	@override
	String toString() {
		return 'Ltc(name: $name, unit: $unit, value: $value, type: $type)';
	}

	factory Ltc.fromJson(Map<String, dynamic> json) {
		return Ltc(
			name: json['name'] as String,
			unit: json['unit'] as String,
			value: json['value'] as double,
			type: json['type'] as String,
		);
	}

	Map<String, dynamic> toJson() {
		return {
			'name': name,
			'unit': unit,
			'value': value,
			'type': type,
		};
	}

	Ltc copyWith({
		String name,
		String unit,
		double value,
		String type,
	}) {
		return Ltc(
			name: name ?? this.name,
			unit: unit ?? this.unit,
			value: value ?? this.value,
			type: type ?? this.type,
		);
	}

	@override
	List<Object> get props => [name, unit, value, type];
}
