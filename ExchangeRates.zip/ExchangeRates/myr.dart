import 'package:equatable/equatable.dart';

class Myr extends Equatable {
	final String name;
	final String unit;
	final double value;
	final String type;

	const Myr({
		this.name,
		this.unit,
		this.value,
		this.type,
	});

	@override
	String toString() {
		return 'Myr(name: $name, unit: $unit, value: $value, type: $type)';
	}

	factory Myr.fromJson(Map<String, dynamic> json) {
		return Myr(
			name: json['name'] as String,
			unit: json['unit'] as String,
			value: json['value'] as double,
			type: json['type'] as String,
		);
	}

	Map<String, dynamic> toJson() {
		return {
			'name': name,
			'unit': unit,
			'value': value,
			'type': type,
		};
	}

	Myr copyWith({
		String name,
		String unit,
		double value,
		String type,
	}) {
		return Myr(
			name: name ?? this.name,
			unit: unit ?? this.unit,
			value: value ?? this.value,
			type: type ?? this.type,
		);
	}

	@override
	List<Object> get props => [name, unit, value, type];
}
