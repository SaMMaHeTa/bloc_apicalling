import 'dart:math';

import 'package:bloc_apicalling/bloc/index.dart';
import 'package:bloc_apicalling/models/PriceList/price_list.dart';
import 'package:bloc_apicalling/models/Users/UserData.dart';
import 'package:dynamic_theme/dynamic_theme.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_speed_dial/flutter_speed_dial.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';

class ChartPage extends StatefulWidget {
  @override
  ChartPageState createState() => ChartPageState();
}

class ChartPageState extends State<ChartPage> with TickerProviderStateMixin {
  List<Color> gradientColors = [
    const Color(0xff23b6e6),
    const Color(0xff02d39a),
  ];

  bool showAvg = false;

  @override
  void initState() {
    super.initState();
  }

  Widget buildBody(BuildContext mainContext) {
    return BlocBuilder<UsersBloc, UsersState>(
      builder: (context, state) {
        print("PRICE LIST BUILDER");
        print(state);
        try {
          // if (state == null ||
          //     state is UsersError ||
          //     state is PriceListLoaded) {
          if (state == null) {
            print("NULL STATE");
            BlocProvider.of<UsersBloc>(mainContext).add(FetchPriceList());
          }
          if (state is UsersEmpty) {
            print("EMPTY STATW");
            BlocProvider.of<UsersBloc>(mainContext).add(FetchPriceList());
          }
          if (state is UsersError) {
            return Center(
              child: Text('failed to fetch quote'),
            );
          }
        } catch (e) {
          print(e);
        }

        if (state is PriceListLoaded) {
          var priceList = state.priceList;
          // print(priceList);
          return AspectRatio(
              aspectRatio: 2 / 1,
              child: Container(
                child: LineChart(
                  mainData(priceList),
                ),
              ));
        }
        return Center(
          child: CircularProgressIndicator(),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    print("ChartPage BUILDED");
    return Scaffold(
      body: buildBody(context),
    );
  }

  LineChartData mainData(PriceList priceList) {
    var data = priceList.prices;

    print([
      "priceList.prices",
      data.map((obj) => FlSpot(obj[0].toDouble(), obj[1].toDouble()))
    ]);

    var barData = data
        .asMap()
        .map((inx, obj) =>
            MapEntry(inx, FlSpot(inx.toDouble(), obj[0].toDouble())))
        .values
        .toList();

    var maxX = barData.map<int>((e) => e.x.toInt()).reduce(max);
    var maxY = barData.map<int>((e) => e.y.toInt()).reduce(max);
    print(["barData", barData.map((obj) => obj.x)]);

    return LineChartData(
      gridData: FlGridData(
        show: false,
        drawVerticalLine: true,
        getDrawingHorizontalLine: (value) {
          return FlLine(
            color: const Color(0xff37434d),
            strokeWidth: 1,
          );
        },
        getDrawingVerticalLine: (value) {
          return FlLine(
            color: const Color(0xff37434d),
            strokeWidth: 1,
          );
        },
      ),
      titlesData: FlTitlesData(
        show: false,
      ),
      borderData: FlBorderData(
          show: true,
          border: Border.all(color: const Color(0xff37434d), width: 1)),
      minX: 0,
      maxX: maxX.toDouble(),
      minY: 0,
      maxY: maxY.toDouble(),
      lineBarsData: [
        LineChartBarData(
          spots: barData,
          isCurved: true,
          colors: gradientColors,
          barWidth: 1,
          isStrokeCapRound: true,
          dotData: FlDotData(
            show: false,
          ),
          belowBarData: BarAreaData(
            show: true,
            colors:
                gradientColors.map((color) => color.withOpacity(0.3)).toList(),
          ),
        ),
      ],
    );
  }
}
