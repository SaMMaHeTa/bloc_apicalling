import 'package:bloc_apicalling/ChartPage.dart';
import 'package:bloc_apicalling/bloc/index.dart';
import 'package:bloc_apicalling/models/Users/UserData.dart';
import 'package:dynamic_theme/dynamic_theme.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_speed_dial/flutter_speed_dial.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';

class HomePage extends StatefulWidget {
  @override
  HomePageState createState() => HomePageState();
}

class HomePageState extends State<HomePage> with TickerProviderStateMixin {
  ScrollController scrollController;
  bool dialVisible = true;

  @override
  void initState() {
    scrollController = ScrollController()
      ..addListener(() {
        setDialVisible(scrollController.position.userScrollDirection ==
            ScrollDirection.forward);
      });
    super.initState();
  }

  void setDialVisible(bool value) {
    setState(() {
      dialVisible = value;
    });
  }

  Widget buildBody(BuildContext mainContenxt) {
    return BlocBuilder<UsersBloc, UsersState>(
      builder: (context, state) {
        print("BLOC BUILDER");
        print(state);
        if (state == null) {
          print("NULL STATE");
          BlocProvider.of<UsersBloc>(context).add(FetchUserData());
        }
        if (state is UsersEmpty) {
          print("EMPTY STATW");
          BlocProvider.of<UsersBloc>(context).add(FetchUserData());
        }
        if (state is UsersError) {
          return Center(
            child: Text('failed to fetch quote'),
          );
        }
        if (state is UsersLoaded) {
          print(state);
          var usersList = state.responseUsers.data;
          return GridView.count(
              crossAxisCount: 2,
              padding: EdgeInsets.all(16.0),
              childAspectRatio: 8 / 10,
              children: _buildGridCards(usersList));
        }
        return Center(
          child: CircularProgressIndicator(),
        );
      },
    );
  }

  buildSpeedDial(BuildContext mainContext) {
    return SpeedDial(
      backgroundColor: Colors.brown,

      overlayColor: Colors.black,
      overlayOpacity: 0.5,

      animatedIcon: AnimatedIcons.menu_close,
      animatedIconTheme: IconThemeData(size: 22.0),
      // child: Icon(Icons.add),
      onOpen: () => print('OPENING DIAL'),
      onClose: () => print('DIAL CLOSED'),
      visible: dialVisible,
      curve: Curves.bounceIn,
      children: [
        SpeedDialChild(
          child: Icon(Icons.accessibility, color: Colors.black),
          backgroundColor: Colors.white,
          onTap: () {
            DynamicTheme.of(context).setBrightness(Brightness.light);
          },
          label: 'LIGHT',
          labelStyle:
              TextStyle(fontWeight: FontWeight.w500, color: Colors.black),
          labelBackgroundColor: Colors.white60,
        ),
        SpeedDialChild(
          child: Icon(Icons.brush, color: Colors.white),
          backgroundColor: Colors.black,
          onTap: () {
            DynamicTheme.of(context).setBrightness(Brightness.dark);
          },
          label: 'DARK',
          labelStyle:
              TextStyle(fontWeight: FontWeight.w500, color: Colors.white),
          labelBackgroundColor: Colors.black,
        ),
        SpeedDialChild(
          child: Icon(Icons.keyboard_voice, color: Colors.white),
          backgroundColor: Colors.blue,
          onTap: () {
            // DynamicTheme.of(context).setBrightness(Brightness.light);

            Navigator.of(mainContext).push(MaterialPageRoute(
                builder: (_) => BlocProvider.value(
                      value: BlocProvider.of<UsersBloc>(mainContext),
                      child: ChartPage(),
                    )));
          },
          labelWidget: Container(
            color: Colors.blue,
            margin: EdgeInsets.only(right: 10),
            padding: EdgeInsets.all(6),
            child: Text('Custom Label Widget'),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    print("HOMEPAGE BUILDED");
    return Scaffold(
      body: buildBody(context),
      floatingActionButton: buildSpeedDial(context),
    );
  }
}
// Card(
//             clipBehavior: Clip.antiAlias,
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: <Widget>[
//                 AspectRatio(
//                   aspectRatio: 18.0 / 11.0,
//                   child: Image.network(user.avatar),
//                 ),
//                 Padding(
//                   padding: EdgeInsets.fromLTRB(16.0, 12.0, 16.0, 8.0),
//                   child: Column(
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: <Widget>[
//                       Text(user.firstName + " " + user.lastName),
//                       SizedBox(height: 8.0),
//                       Text(user.email),
//                     ],
//                   ),
//                 ),
//               ],
//             ),
//           ),

List<AnimationConfiguration> _buildGridCards(List<UserData> data) {
  List<AnimationConfiguration> cards = List.generate(data.length, (int index) {
    var user = data[index];
    return AnimationConfiguration.staggeredGrid(
        columnCount: data.length,
        position: index,
        duration: Duration(milliseconds: 375),
        child: ScaleAnimation(
          scale: 0.5,
          child: FadeInAnimation(
            child: Card(
              clipBehavior: Clip.antiAlias,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  AspectRatio(
                    aspectRatio: 18.0 / 11.0,
                    child: Image.network(user.avatar),
                  ),
                  Padding(
                    padding: EdgeInsets.fromLTRB(16.0, 12.0, 16.0, 8.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(user.firstName + " " + user.lastName),
                        SizedBox(height: 8.0),
                        Text(user.email),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ));
  });

  return cards;
}
