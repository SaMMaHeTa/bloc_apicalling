import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:bloc_apicalling/models/PriceList/price_list.dart';
import 'package:bloc_apicalling/models/Users/response_users.dart';
import 'package:bloc_apicalling/repositories/ApiRepoRepository.dart';
import 'package:equatable/equatable.dart';
import 'package:meta/meta.dart';

part 'users_event.dart';
part 'users_state.dart';

class UsersBloc extends Bloc<UsersEvent, UsersState> {
  final ApiRepoRepository apiRepoRepository;

  UsersBloc({@required this.apiRepoRepository})
      : assert(apiRepoRepository != null),
        super(UsersEmpty());

  @override
  Stream<UsersState> mapEventToState(
    UsersEvent event,
  ) async* {
    print("BLOC MAP EVENT");
    print(event);
    if (event is FetchUserData) {
      yield UsersLoading();
      try {
        final ResponseUsers responseUsers =
            await apiRepoRepository.getUsersData();
        yield UsersLoaded(responseUsers: responseUsers);
      } catch (e) {
        print(e);
        yield UsersError();
      }
    }
    if (event is FetchPriceList) {
      yield UsersLoading();
      try {
        final PriceList priceList = await apiRepoRepository.getPriceList();
        yield PriceListLoaded(priceList: priceList);
      } catch (e) {
        print(e);
        yield UsersError();
      }
    }
  }
}
