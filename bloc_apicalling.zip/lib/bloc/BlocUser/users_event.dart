part of 'users_bloc.dart';

abstract class UsersEvent extends Equatable {
  const UsersEvent();
  // @override
  // List<Object> get props => [];
}

class FetchUserData extends UsersEvent {
  const FetchUserData();

  @override
  List<Object> get props => [];
}

class FetchPriceList extends UsersEvent {
  const FetchPriceList();

  @override
  List<Object> get props => [];
}
