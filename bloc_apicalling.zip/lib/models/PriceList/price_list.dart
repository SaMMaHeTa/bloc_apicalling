import 'package:equatable/equatable.dart';

class PriceList extends Equatable {
  final List<List<num>> prices;

  const PriceList({this.prices});

  @override
  String toString() => 'PriceList(prices: $prices)';

  factory PriceList.fromJson(Map<String, dynamic> json) {
    // print(json);
    var array = List<List<num>>();
    // print("JSON::");
    var prices = json['prices'] as List<dynamic>;
    print(prices);
    prices.forEach((e) {
      // if (e != null) {
      print("subObj::");
      print(e);
      // (e as List<num>)?.map((subObj) {
      array.add([e[0], e[1]]);
      // });
      // }
    });
    return PriceList(prices: array);
    // return PriceList(
    //   prices: json['prices'] as List<List<num>>,
    // );
  }

  Map<String, dynamic> toJson() {
    return {
      'prices': prices,
    };
  }

  PriceList copyWith({
    List<List<num>> prices,
  }) {
    return PriceList(
      prices: prices ?? this.prices,
    );
  }

  @override
  List<Object> get props => [prices];
}
