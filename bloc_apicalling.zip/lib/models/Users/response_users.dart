import 'package:equatable/equatable.dart';

import "UserData.dart";
import "support.dart";

class ResponseUsers extends Equatable {
  final int page;
  final int perPage;
  final int total;
  final int totalPages;
  final List<UserData> data;
  final Support support;

  const ResponseUsers({
    this.page,
    this.perPage,
    this.total,
    this.totalPages,
    this.data,
    this.support,
  });

  @override
  String toString() {
    return 'ResponseUsers(page: $page, perPage: $perPage, total: $total, totalPages: $totalPages, data: $data, support: $support)';
  }

  factory ResponseUsers.fromJson(Map<String, dynamic> json) {
    print("MODEL USERDATA");
    print(json['data']);
    return ResponseUsers(
      page: json['page'] as int,
      perPage: json['per_page'] as int,
      total: json['total'] as int,
      totalPages: json['total_pages'] as int,
      data: (json['data'] as List<dynamic>)?.map((e) {
        return e == null ? null : UserData.fromJson(e as Map<String, dynamic>);
      })?.toList(),
      support: json['support'] == null
          ? null
          : Support.fromJson(json['support'] as Map<String, dynamic>),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'page': page,
      'per_page': perPage,
      'total': total,
      'total_pages': totalPages,
      'data': data?.map((e) => e?.toJson())?.toList(),
      'support': support?.toJson(),
    };
  }

  ResponseUsers copyWith({
    int page,
    int perPage,
    int total,
    int totalPages,
    List<UserData> data,
    Support support,
  }) {
    return ResponseUsers(
      page: page ?? this.page,
      perPage: perPage ?? this.perPage,
      total: total ?? this.total,
      totalPages: totalPages ?? this.totalPages,
      data: data ?? this.data,
      support: support ?? this.support,
    );
  }

  @override
  List<Object> get props {
    return [
      page,
      perPage,
      total,
      totalPages,
      data,
      support,
    ];
  }
}
