import 'dart:async';
import 'dart:io';
import 'dart:convert' as convert;
import 'package:bloc_apicalling/models/PriceList/price_list.dart';
import 'package:http/http.dart' as http;

import 'package:bloc_apicalling/models/Users/response_users.dart';
import 'package:meta/meta.dart';

class ApiRepoRepositoryProvider {
  final _baseUrl = 'https://reqres.in/api';
  final HttpClient httpClient;
  const ApiRepoRepositoryProvider({@required this.httpClient})
      : assert(httpClient != null);
  Future<ResponseUsers> getUsersData() async {
    print("CALLING API");
    final url = '$_baseUrl/users?page=2';
    var response = await http.get(url);
    print(response);
    if (response.statusCode == 200) {
      var jsonResponse = convert.jsonDecode(response.body);
      return ResponseUsers.fromJson(jsonResponse);
    } else {
      throw new Exception('error getting quotes');
    }
  }

  Future<PriceList> getPriceList() async {
    print("CALLING PRICE LIST");
    final url =
        'https://api.coingecko.com/api/v3/coins/bitcoin/market_chart?vs_currency=usd&days=1';
    var response = await http.get(url);
    try {
      // print(response);
      if (response.statusCode == 200) {
        var jsonResponse = convert.jsonDecode(response.body);
        // print(jsonResponse);
        return PriceList.fromJson(jsonResponse);
      } else {
        throw new Exception('error getting quotes');
      }
    } catch (e) {
      print(e);
      throw new Exception('error getting quotes');
    }
  }
}
